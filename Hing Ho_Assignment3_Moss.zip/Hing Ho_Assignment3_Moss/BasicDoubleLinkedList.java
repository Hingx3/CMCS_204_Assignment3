import java.util.ArrayList;
import java.util.Comparator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

public class BasicDoubleLinkedList<T> implements Iterable<T>{	
	protected int size;
	protected Node head;
	protected Node tail;
	
	/**
	 * A generic inner class named DoubleLinkedListIterator 
	 * that implements java’s ListIterator interface (for the iterator method).
	 * This class only implements the next(), hasNext(), previous() and hasPrevious() methods 
	 * of the ListIterator interface. (Follow java API documentation of ListIterator interface 
	 * for the implementing these methods.)
	 * The rest of the methods should throw the UnsupportedOperationException
	 */
	public class DoubleLinkedListIterator implements ListIterator<T> {		 
		protected Node nextNode;	        
		protected Node previousNode;
		
		public DoubleLinkedListIterator() {
			this.nextNode = head;
            this.previousNode = null;
		}

		@Override
		public boolean hasNext() {
			return nextNode != null;
		}

		@Override
		public T next() {
			if (hasNext()) {
				previousNode = nextNode;
				nextNode = nextNode.next;
		        return previousNode.data;
		      }
		      throw new NoSuchElementException();	
		}

		@Override
		public boolean hasPrevious() {
			 return previousNode != null;			
		}

		@Override
		public T previous() {
			if (hasPrevious()) {
				nextNode = previousNode;
				previousNode = previousNode.prev;
		        return nextNode.data;
		      }
		      throw new NoSuchElementException();
			
		}

		@Override
		public int nextIndex() throws UnsupportedOperationException{
			throw new UnsupportedOperationException();
		}

		@Override
		public int previousIndex() throws UnsupportedOperationException{
			throw new UnsupportedOperationException();
		}

		@Override
		public void remove() throws UnsupportedOperationException{
			throw new UnsupportedOperationException();
			
		}

		@Override
		public void set(T arg0) throws UnsupportedOperationException{
			throw new UnsupportedOperationException();
			
		}

		@Override
		public void add(T arg0) throws UnsupportedOperationException{
			throw new UnsupportedOperationException();
			
		}
		
	}
	
	/**
	 * A generic inner class Node
	 * This class has the following attributes:
	 * data of type T
	 * prev of type Node
	 * next of type Node
	 */
	public class Node {
		protected T data;
		protected Node prev;
	    protected Node next;
	    	    
	    public Node(T dataNode) {	    	
	    	this.data = dataNode;
	    	this.prev = null;	      
	    	this.next = null;	      	    
	    }	  
	}

	
	
	
	
	/**
	 * Constructor to set to initialize head, tail 
	 * and size to null, null and 0
	 */
	public BasicDoubleLinkedList() {
		size = 0;
		head = null;
		tail = null;
	}
	
	/**
	 * Adds an element to the end of the list and updated the size of the list
	 * @param data - the data to be added to the list
	 * @return 
	 */
	public BasicDoubleLinkedList<T> addToEnd(T data) {
		Node newTail = new Node(data);

	    if (size == 0) {
	      head = newTail;
	      tail = head;
	    } else {
	      tail.next = newTail;
	      newTail.prev = tail;
	      tail = newTail;
	    }
	    size++;	
	    return this;
	}
	
	/**
	 * Adds element to the front of the list and updated the size of the list
	 * @param data - the data to be added to the list
	 * @return 
	 */
	public BasicDoubleLinkedList<T> addToFront(T data) {
		Node newHead = new Node(data);
		
	    if (size == 0) {
	      head = newHead;
	      tail = head;
	    } else {
	      head.prev = newHead;
	      newHead.next = head;
	      head = newHead;
	    }
	    size++;
	    return this;
	}
	
	/**
	 * Returns but does not remove the first element from the list.
	 * If there are no elements the method returns null.
	 * @return the data element or null
	 */
	public T getFirst() {		 
		if (size == 0) {		      
			return null;		    
		}		    
		return head.data;	
	}
	

	/**
	 * Returns but does not remove the last element from the list.
	 * If there are no elements the method returns null. Do not implement this method using iterators.
	 * @return the data element or null
	 */
	public T getLast() {		 
		if (size == 0) {		     
			return null;		  
		}		   
		return tail.data;		
	}
	
	/**
	 * Returns the number of nodes in the list.
	 * @return the number of nodes in the list.
	 */
	public int getSize() {		
		return size;	 
	}
	
	/**
	 * This method returns an object of the DoubleLinkedListIterator.
	 * @return a ListIterator object
	 */
	public ListIterator<T> iterator(){
		return new DoubleLinkedListIterator();
	}
	
	/**
	 * Removes the first instance of the targetData from the list.
	 * @param targetData
	 * @param comparator
	 * @return a node containing the targetData or null
	 */
	public BasicDoubleLinkedList.Node remove​(T targetData, Comparator<T> comparator){				
		Node targetNode = head;
		    
		while (targetNode != null) {		      
			if (comparator.compare(targetData, targetNode.data) == 0) {		        
				if (targetNode == head) {	         
					head = head.next;		       
				} 
				else if (targetNode == tail) {		        
					tail = tail.prev;		        
				} 
				else {		        		
					targetNode.prev.next = targetNode.next;		       
				}		       
				size--;		       
				return null;		     
			}		     
			targetNode = targetNode.next;		   
		}		
		return targetNode;
	}
	
	/**
	 * Removes and returns the first element from the list. 
	 * If there are no elements the method returns null. 
	 * Do not implement this method using iterators
	 * @return data element or null
	 */
	public T retrieveFirstElement(){		
		T first = head.data;	
		
		if (size == 0) {		     
			return null;	   
		}		   	   
		
		if (size == 1) {		  
			head = null;  
			tail = null;
		} 
		else {
			head = head.next;
			head.prev = null;
		}
		size--;	
		return first;
	}
	
	/**
	 * Removes and returns the last element from the list. 
	 * If there are no elements the method returns null. 
	 * Do not implement implement this method using iterators.
	 * @return data element or null
	 */
	public T retrieveLastElement() {	
		T last = tail.data;
		
		if (size == 0) {		      
			return null;		    
		}		    
		
		if (size == 1) {	     
			head = null;		      
			tail = null;		    
		} 
		else {
			tail = tail.prev;		      
			tail.next = null;		    
		}		   
		size--; 
		return last;
	}
	
	/**
	 * Returns an arraylist of all the items in the Double Linked list
	 * @return an arraylist of the items in the list
	 */
	public ArrayList<T> toArrayList(){		
		ArrayList<T> list = new ArrayList<>();	    
		Node current = head;		
	    
		while (current != null) {	     
			list.add(current.data);	     
			current = current.next;	    
		}  
		return list;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
