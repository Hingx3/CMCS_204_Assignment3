import java.util.Comparator;
import java.util.ListIterator;

public class SortedDoubleLinkedList<T> extends BasicDoubleLinkedList<T>{
	protected Comparator<T> compareableObject;
		
	public SortedDoubleLinkedList(Comparator<T> compareableObject) {	  		
		this.compareableObject = compareableObject;	  
	}
	
				
	/**
	 * Inserts the specified element at the correct position in the sorted list
	 * @param data - the data to be added to the list
	 */
	public SortedDoubleLinkedList<T> add​(T data) {					
		Node newNode = new Node(data);		   				
		Node previous = this.tail;					
		Node current = this.head;
			
		if (size == 0) {		      							
			head = newNode;		      						
			tail = head;      							
			size++;				 
			return this;
		}					
		else if (compareableObject.compare(head.data, data) > 0){			
			newNode.next = head;		      							
			head.prev = newNode;		     						
			head = newNode;		      							
			size++;	
			return this;
		}				
		else {							
			while (compareableObject.compare(current.data, data) < 0) {									
				if (current.next == null) {								
					current.next = newNode;		         									
					newNode.prev = current;		          										
					tail = newNode;		          											
					size++;	
					return this;
				} 									
				else {		        											
					current = current.next;		        								
				}																						
			}
			current.prev.next = newNode;		      							
			newNode.prev = current.prev;		      							
			current.prev = newNode;		      								
			newNode.next = current;		     									
			size++;	
			return this;
		}
	}
		
	/**
	 * This operation is invalid for a sorted list.
	 * @param data - the data element to be removed
	 * @throws UnsupportedOperationException if method is called
	 */
	@Override	 
	public BasicDoubleLinkedList<T> addToEnd(T data) throws UnsupportedOperationException {	    
		throw new UnsupportedOperationException();	  
	}
	
	/**
	 * This operation is invalid for a sorted list.
	 * @param data - the data element to be removed
	 * @throws UnsupportedOperationException if method is called
	 */
	@Override	  
	public BasicDoubleLinkedList<T> addToFront(T data) throws UnsupportedOperationException {	    
		throw new UnsupportedOperationException();	 
	}

	/**
	 * Implements the iterator by calling the super class iterator method.
	 * @return an iterator positioned at the head of the list
	 */
	@Override
	public ListIterator<T> iterator(){		 
		return super.iterator();
	}
	
	
	/**
	 * Implements the remove operation by calling the super class remove method.
	 * @param data - the data element to be removed
	 * @param comparator - the comparator to determine equality of data elements
	 * @return a node containing the data or null
	 */
	@Override
	public BasicDoubleLinkedList.Node remove​(T data, Comparator<T> comparator){
		return super.remove​(data, comparator);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}


